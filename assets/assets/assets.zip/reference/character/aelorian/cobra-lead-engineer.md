---
title: Cobra Lead Engineer
description: Ryuuko is her life work
published: true
date: 2023-10-05T10:20:47.730Z
tags: 
editor: markdown
dateCreated: 2023-09-20T02:57:18.891Z
---

# Header
Your content here