---
title: Jacob
description: The Courier
published: true
date: 2023-12-17T07:53:30.416Z
tags: 
editor: markdown
dateCreated: 2023-12-17T07:47:11.887Z
---

Name: Jacob
Gender: Male 
20 years old, 6'29 (192 cm)
Straight/bi curious
Species: Eurasian jay

Additional info:
Dresses in comfortable clothes depending on the weather ( ie Shirt and shorts in summer, pullover and Jeans in winter)
Doesn't really care what people think about his clothing style
Enjoys listening to  Argent Metal (The music featured in DOOM and Doom Eternal 
Likes drinking mead and has a pet jumping spider 
Is a volunteer firefighter
Bit silenced around new people but is a great talker once he is more comfortable 
Sucker for everything wholesome