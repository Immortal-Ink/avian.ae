---
title: Introduction
description: 
published: true
date: 2023-11-24T05:51:35.462Z
tags: 
editor: markdown
dateCreated: 2023-11-24T04:35:52.925Z
---

- [Introduction to the VIPER unit *An overview of the robot and its purpose.*](/reference/character/aelorian/ryuuko/manual/ch1/s1)
- [Purpose and Scope *Explanation of what the manual covers and its intended audience.*](/reference/character/aelorian/ryuuko/manual/ch1/s2)
- [Safety Precautions *Essential safety guidelines and precautions for using and maintaining the robot.*](/reference/character/aelorian/ryuuko/manual/ch1/s3)
{.links-list}