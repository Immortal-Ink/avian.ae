---
title: Legs and Talons
description: 
published: true
date: 2023-11-24T06:20:28.059Z
tags: 
editor: markdown
dateCreated: 2023-11-24T04:39:06.263Z
---

- [Leg and Talon Components and Functions *Detailed descriptions of the components in the robot's legs and talon and their functions*](/reference/character/aelorian/ryuuko/manual/ch6/s1)
- [Leg and Talon Calibration *Procedures for calibrating and fine-tuning the legs and talon*](/reference/character/aelorian/ryuuko/manual/ch6/s2)
- [Troubleshooting Legs and Talons *Guidance for identifying and resolving issues with the legs and talon*](/reference/character/aelorian/ryuuko/manual/ch6/s3)
{.links-list}