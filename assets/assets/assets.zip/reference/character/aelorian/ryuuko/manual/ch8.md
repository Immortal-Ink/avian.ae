---
title: Mobility and Flight
description: 
published: true
date: 2023-11-24T06:34:21.910Z
tags: 
editor: markdown
dateCreated: 2023-11-24T04:43:23.693Z
---

- [Locomotion Mechanisms *Explanation of how the robot moves and its locomotion and flight systems*](/reference/character/aelorian/ryuuko/manual/ch8/s1)
- [Motion Control *Details about controlling the robot's movement*](/reference/character/aelorian/ryuuko/manual/ch8/s2)
- [Troubleshooting Mobility *Guidance for identifying and resolving mobility-related issues*](/reference/character/aelorian/ryuuko/manual/ch8/s3)
{.links-list}