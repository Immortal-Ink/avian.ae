---
title: Wings, Arms and Hands
description: 
published: true
date: 2023-11-24T06:18:10.816Z
tags: 
editor: markdown
dateCreated: 2023-11-24T04:38:37.399Z
---

- [Wing, Arm and Hand Components and Functions *Detailed descriptions of the components in the robot's arms and hands and their functions*](/reference/character/aelorian/ryuuko/manual/ch5/s1)
- [Wing, Arm and Hand Calibration *Procedures for calibrating and fine-tuning the arms and hands*](/reference/character/aelorian/ryuuko/manual/ch5/s2)
- [Troubleshooting Arms and Hands *Guidance for identifying and resolving issues with the arms and hands*](/reference/character/aelorian/ryuuko/manual/ch5/s3)
{.links-list}