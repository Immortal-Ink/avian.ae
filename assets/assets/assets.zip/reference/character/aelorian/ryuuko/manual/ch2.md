---
title: Getting Started
description: 
published: true
date: 2023-11-24T06:01:37.683Z
tags: 
editor: markdown
dateCreated: 2023-11-24T04:36:36.915Z
---

- [Unit Overview *Detailed introduction to the robot's physical structure and key components*](/reference/character/aelorian/ryuuko/manual/ch2/s1)
- [Modifying Power State *Instructions for safely turning the robot on and off*](/reference/character/aelorian/ryuuko/manual/ch2/s2)
- [Setup and Calibration *Steps for the initial setup and calibration process*](/reference/character/aelorian/ryuuko/manual/ch2/s3)
- [User Interface *Explanation of the robot's user interface and how to interact with it*](/reference/character/aelorian/ryuuko/manual/ch2/s4)
{.links-list}