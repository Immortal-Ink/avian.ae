---
title: Sensors and Perception
description: 
published: true
date: 2023-11-24T06:22:12.184Z
tags: 
editor: markdown
dateCreated: 2023-11-24T04:39:55.985Z
---

- [Sensor Types and Locations *Overview of the various sensors used in the robot and their placements*](/reference/character/aelorian/ryuuko/manual/ch7/s1)
- [Sensor Calibration *Procedures for calibrating and optimizing sensor performance*](/reference/character/aelorian/ryuuko/manual/ch7/s2)
- [Troubleshooting Sensors *Guidance for identifying and resolving sensor-related issues*](/reference/character/aelorian/ryuuko/manual/ch7/s3)
{.links-list}