---
title: Torso
description: 
published: true
date: 2023-11-24T06:16:00.769Z
tags: 
editor: markdown
dateCreated: 2023-11-24T04:37:40.834Z
---

- [Torso Components and Functions *Detailed descriptions of the components in the robot's torso and their functions*](/reference/character/aelorian/ryuuko/manual/ch4/s1)
- [Torso Calibration *Procedures for calibrating and fine-tuning the torso*](/reference/character/aelorian/ryuuko/manual/ch4/s2)
- [Troubleshooting the Torso *Guidance for identifying and resolving torso-related issues*](/reference/character/aelorian/ryuuko/manual/ch4/s3)
{.links-list}