---
title: Bobo
description: Bartender on bird planet
published: true
date: 2023-10-05T10:17:20.894Z
tags: 
editor: markdown
dateCreated: 2023-09-20T03:02:46.421Z
---

https://x.com/ClawedDrip/status/1646239547792166912?s=20