---
title: The High Court (Affectionately called The Roost)
description: Headquarters for the ministry of justice
published: true
date: 2023-10-26T19:19:10.138Z
tags: 
editor: markdown
dateCreated: 2023-10-26T19:19:10.138Z
---

# Header
Your content here