---
title: Energy Headquarters (Destroyed)
description: 
published: true
date: 2023-10-26T19:09:07.298Z
tags: 
editor: markdown
dateCreated: 2023-10-26T19:09:07.298Z
---

# Header
Your content here