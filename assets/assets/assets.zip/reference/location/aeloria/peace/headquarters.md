---
title: Monolith (Peace Headquarters)
description: 
published: true
date: 2023-10-26T19:10:45.042Z
tags: 
editor: markdown
dateCreated: 2023-10-26T19:10:45.042Z
---

# Header
Your content here