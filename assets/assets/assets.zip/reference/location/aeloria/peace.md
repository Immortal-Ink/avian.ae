---
title: City of Peace
description: Headquarters for the ministry of peace
published: true
date: 2023-10-26T19:03:19.064Z
tags: 
editor: markdown
dateCreated: 2023-10-26T19:03:19.064Z
---

# Header
Your content here