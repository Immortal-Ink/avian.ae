---
title: City of Justice
description: Headquarters for the ministry of justice
published: true
date: 2023-10-26T19:02:55.863Z
tags: 
editor: markdown
dateCreated: 2023-10-26T19:02:55.863Z
---

# Header
Your content here