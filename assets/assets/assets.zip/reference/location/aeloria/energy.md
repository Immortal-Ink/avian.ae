---
title: City of Energy
description: Destroyed Headquarters for the ministry of energy.
published: true
date: 2023-10-26T19:03:48.976Z
tags: 
editor: markdown
dateCreated: 2023-10-26T19:03:48.976Z
---

# Header
Your content here