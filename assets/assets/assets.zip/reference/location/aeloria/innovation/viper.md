---
title: The VIPER Construct
description: Secure facility for the R&D for project VIPER, the creation of Ryuuko.
published: true
date: 2023-10-26T19:21:22.714Z
tags: 
editor: markdown
dateCreated: 2023-10-26T19:21:22.714Z
---

# Header
Your content here