---
title: City of Innovation
description: Headquarters for the ministry of innovation.
published: true
date: 2023-10-26T19:14:31.157Z
tags: 
editor: markdown
dateCreated: 2023-10-26T17:41:24.902Z
---

Hahaha content