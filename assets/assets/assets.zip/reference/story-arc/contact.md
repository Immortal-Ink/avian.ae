---
title: First Contact
description: A deal with a Dragon/Dragon deez nuts
published: true
date: 2023-10-15T20:52:58.446Z
tags: 
editor: markdown
dateCreated: 2023-10-14T16:36:14.304Z
---

## Scene 1
After escaping the planet Ryuuko needs to find a jump-capable ship. She finds herself at a mining colony on the other side of the star system from Aeloria. Here, she makes it known that she is looking for work in exchange for a ship, or the funds to buy one. Eventually, she is informed of a shady dealer who pays incredibly well for very dangerous missions, most mercs dont return from their jobs with them. The only way to contact you is by finding one of your drones out on the surface of the planet.

## Scene 2
Ryuuko searches the barren wastelands of the mining planet, locates a surveilance drone, and follows it back to its home base without alerting the security control system. When i approach the building, a door automatically opens for me and I go inside. Impressed by my ability to evade the system, and sneak up on the base, the dealer has opened the way for me to enter and is intriguied enough to meet me.

## Scene 3
Ryuuko meets with the dealer, who claims to be a collector, who wants an artifact that was stolen from him by another collector, and tasks ryuuko with breaking in and snatching this artifact and returning it. In exchange for extreme pay. Is provided with a really good ship, and a survailence drone to join you.

## Scene 4
Ryuuko completes the snatch-and-grab, but does sustain some damage from the security system. On my flight back, i begin my repair process, in doing so, I attune the nanites in the artifact to me without realizing it because they are enearby. the survailence drone sends footage of the repair process back to the dealer.

## Scene 5
On my return, the nanites dont work for the dealer who tries to take them out and manipulate them, he blames me, looks through the footage, realizes my repair process is a resonator, he gets frustrated, and realizes he needs to tear the resonator from my body if he must, but I fight back, during the fight I pull out my two blades, and the dealer jokingly matches my weapons by summoning a pair from his nanites, and we fight a little bit, before he eventually breaks my blades with his. He is toying with me. in the background ive been analysing the nanite summoning of his blades, and attempt to recreate the resonance i recorded, which results in the stolen artifact responding to me and creating a pair in my own hands. Which absolutely fucking sets him off. I escape because he begins making mistakes due to his absolute rage, and his low supply of nanites.

End comic with me flying off planet in my newly stolen spaceship. And the nanites

# Notes
This comic sets up another villain, introduces the readers to the nanites in depth, and the species that made them, as well as unlocks the new ability of ryuukos to summon their blades with nanites. This finished the introductory story arc for ryuuko
