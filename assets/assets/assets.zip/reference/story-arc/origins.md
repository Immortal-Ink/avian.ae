---
title: Origins Storyboarding
description: 
published: true
date: 2023-10-15T20:59:37.419Z
tags: 
editor: markdown
dateCreated: 2023-10-14T14:27:55.878Z
---

Origins focuses on not the backstory of the viper lab, but the characters involved in creating ryuuko. Its main purpose is to worldbuild the government, science, and religion of the society, as well as introduce key characters like scientists, and government officials involved in the project, setting up each individuals plot twist or character development arc. The comic ends right before they boot up the final revision of ryuuko.

---

## Scene 1 - Auditor's Office - Ground
Short Flashback of Wrenna childhood. Showcase a bright and curious mind with childlike wonder. Use this scene to worldbuild an incredibly happy and healthy society, perhaps with pristine buildings, a health population, etc.

Flashback interrupted, her attention snapped back to the present by someone calling her name. She is at a budget review meeting and is being grilled by a goverment higherup. As the the Chief of Robotics under the Director of the Ministry of Innovation she is currently fighting for more budget and resources for a project that was requested by the Ministry of Peace. 

The goverment auditor is demanding more details about the project. Wrenna stonewalls, claiming the information is classified but she clearly has the official paperwork sanctioning the project, as well as a memo from the Director (of the MOP) requesting the additional resources, and that it would be sufficient. The auditor reluctantly approves the budget.

---

## Scene 
At some point Wrenna should step out to The Ground where we show that society's undesireables reside in less-than-ideal circumstances.
> Distastefully and simply called "The Ground", the lower half of most Aelorian cities are dedicated to the infrastructure required to run the city, such as waste, energy, etc. The Ground is the home of criminals, sick, elderly and disabled, and is not maintained anywhere near as well as the cities themselves. This creates a natural class system with the wealthy/healthy above and the sick and accused below.
{.is-info}

---

## Scene 
Need to plan out a scene where we can challenge her morals and let her take a stance on where her morals are.

## Scene 
A scene where she actually works on Ryuuko without showing Ryuuko. Should use this scene to develope her relationship with her staff. We should show a couple of co-workers with very close positive relationships who are all passionate about the project, and at least one co-worker who has distaste for the project, but loyalty to their boss.
