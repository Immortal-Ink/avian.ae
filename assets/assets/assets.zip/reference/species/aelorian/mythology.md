---
title: Aelorian Mythology
description: 
published: true
date: 2023-12-24T11:39:45.954Z
tags: 
editor: markdown
dateCreated: 2023-12-24T11:24:44.163Z
---

# Spirits
Aelorian mythology has a variety of personifications of various natural forces. These are not a core part of their religious beliefs, which focus mainly on ancestral worship and the natural cycles of things. Aelorians understand these forces are not necessarily sentient spirits, but instead personify them to make it easier to discuss, and to show respect for those forces. 

A popular spirit, Death, who they see as an entity responsible for beauty in shadow and darkness, has alot of mythology surrounding the force of nature.
- [Death](/reference/species/aelorian/mythology/spirit/death)
{.links-list}

notes:
I would like to detail a myth about a personification of death. in the myth, death goes to the living who experience great grief over a lost loved one. Death can guide the grieving to their lost loved one when they themselves die, but only if they die fulfilled. if they die unfulfilled, then death cannot guide them, they remain as spirits on aeloria. so death marks their heart and skin with goals the individual must achieve, the last goal depicting them reunited with their lost loved one. the goals are personal to each individual, who will follow them only to get to the end goal which they think is death promising to return their lost one to them, but in reality the goals lead that individual down a healthy, happy and fulfilling life. As they complete the goals, the marks disappear, and in doing so, also lifts a little more weight and grief from their soul. and when they grow old and finally die, having completed all the goals, death brings them to reunite with their loved one. 