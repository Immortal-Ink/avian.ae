---
title: Ministry of Environment
description: 
published: true
date: 2023-10-26T18:08:41.122Z
tags: 
editor: markdown
dateCreated: 2023-10-26T18:08:41.122Z
---

# Header
Your content here