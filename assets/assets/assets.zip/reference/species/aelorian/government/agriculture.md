---
title: Ministry of Agriculture
description: 
published: true
date: 2023-10-14T15:33:51.478Z
tags: 
editor: markdown
dateCreated: 2023-10-12T00:07:07.241Z
---

# Ministry of Agriculture





## Structure
| Division                         | Description |
|----------------------------------|-------------|
| Food Safety                      |             |
| Liason to Ministry of Innovation |             |
| Distribution                     |             |
| Something else                   |             |
| Yeah                             |             |