---
title: Ministry of Innovation
description: 
published: true
date: 2023-10-26T17:55:09.429Z
tags: 
editor: markdown
dateCreated: 2023-10-26T17:55:09.429Z
---

The Ministry of Innovation, headquartered in the [City of Innovation](/reference/location/aeloria/innovation), is in charge of Aelorias technical research, development, and refinement. The ministry works in close collaboration with other ministries on aeloria to fulfill research, development, and production of equipment, tech, and scientific advancement.

For agriculture, innovation continues to constantly improve farming technology, techniques, and throughput, advancements in hydropponics, genetic manipulation and selective breeding to name a few to best supply aeloria with all the food and natural resouces it needs.

For heritage, innovation builds learning technology, and tools, instruments and educational guides, authors books and texts, sponsors courses etc.

For peace, innovation handles war tech, robotics, advanced weaponry, etc.