---
title: Chikage
description: 近景
published: true
date: 2023-12-25T08:06:32.876Z
tags: 
editor: markdown
dateCreated: 2023-12-24T11:25:08.872Z
---

In Aelorian society, Death in the form of a young girl, serves as a guide for fulfilled souls to the afterlife. She cannot guide those who died with a heavy soul, anchored to Aeloria as an ancestral spirit to teach their future generations in hopes they avoid the same life path.

Death takes a special interest in those who experience great grief having lost a loved one who died happy and fulfilled. Especially when that grief risks weighing themselves down and preventing them from moving on themselves.

Myths and poems depict death appearing before such troubled souls, and peering into the infinite life paths within the shadow in their hearts, marks them (interpretations vary, but some depict this as tattoos upon the body, others depict this as marks upon the heart) with goals or challenges, leading up to the promise they can be reunited with their lost loved one. It is a trick, the seemingly unimportant tasks take a lifetime to achieve, and cause fulfilling life moments, as each goal is completed, the mark fades away, and takes some grief or shadow from the soul with it.

After living a long and fulfilled life, they die happy, and Death can guide them to their lost beloved in the afterlife. Fulfilling the visions she gave them in the beginning, a promise from death to the broken.

---
### A song passed down through generations.

In sorrow's realm, where shadows creep,
Death appears with whispers deep.
Guiding hearts in grief's cruel grasp,
A cosmic dance in shadows clasped.

Marked on skin, etched by despair,
Goals unfold, a journey rare.
Personal quests, life's tapestry,
A path to joy, from agony free.

Each mark a goal, a life's decree,
Guided by Death, in destiny.
The last, a promise, reunion's sign,
Yet hidden truths in paths entwine.

As marks dissolve, burdens lift,
Grief's weight, a subtle shift.
A tale unfolds of myths untold,
Death, companion, compassionate and bold.

Fulfill these quests, embrace life's grace,
In Death's dance, a tranquil space.
A fulfilled end, a soul set free,
Guided to reunion, eternally.

---
### Paintings found on the side of a cliff
There is a mural on a mountain side, depicting a young boy, climbing a tree with their childhood friend. In the next depiction, she falls to her death, and the boy and his village are depicted mourning. 
Death, a young bird, cloaked in shadow appears only to the boy, and shows him visions of him hunting a great predator, constructing a great array of tools and machines, dancing with children that look like they could be his siblings, and standing before a great valley. The visions end with a depiction of the young boy, and his childhood friend together once more, running through the forest.
The boy is depicted as seeing these as challenges presented by death in exchange for the return of his friend. "Do these, and be together again" he thinks.
The boy is then depicted protecting a girl from a predator, striking it down and killing it. They fall in love.
He is then depicted building tools, and performing work that supports his village. Building a life for himself and his mate.
Then, depicted much older, he dances with what we now understand to be his children with the girl he saved and married.
And finally, as an old bird, he sits atop a mountain, under a tree, looking across a beautiful valley.
Death returns, and holds out a hand, the boys spirit reaches up and takes it, leaving his body behind, and death leads him into the sky, where his childhood friend is waiting for him, and they are reunited as children, to forever play in the afterlife.

---

