---
title: Aelorian Species Design
description: 
published: true
date: 2024-04-15T04:45:39.684Z
tags: 
editor: markdown
dateCreated: 2024-04-15T04:45:39.684Z
---

# Header
Your content here